# 06 - Photo Gallery - Flexbox
------
Problems for in-class lab for the [“HTML & CSS”](https://softuni.bg/trainings/2375/html-and-css-may-2019) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1236/Flexbox).

## Tasks
* Create an **"index.html"** file with title - **"Photo Gallery - Flexbox"**

## Constraints
* Add section with class **gallery** *(section.gallery)*
* Add **unordered list** with **list items** and **images** inside
* Change the body, ul and li **display** property to **flex**
	